﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication3.Models
{
    public class ElUsuario
    {

        public int codigo { get; set; }
        public string nombre { get; set; }
        public string cargo { get; set; }
    }
}